const mysql = require('mysql');
const express = require('express');
var app = express();
const bodyparser = require('body-parser');
app.use(bodyparser.json());
var path =require('path');
app.set('view engine','ejs');
app.set('views','../views');
var urlencodedParser = bodyparser.urlencoded({extended :false});


app.use('/assets/stylesheets',express.static(path.join(__dirname,'/../assets/stylesheets')));
app.use('/assets/images',express.static(path.join(__dirname,'/../assets/images')));

var mysqlConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'Mobile_meals',
    port:'3306'
});

mysqlConnection.connect((err) => {
    if (!err)
        console.log('DB connection succeded.');
    else
        console.log('DB connection failed \n Error : ' + JSON.stringify(err, undefined, 2));
});


app.listen(3000, () => console.log('Express server is runnig at port no : 3000'));


//Get all person
app.get('/person', (req, res) => {
    mysqlConnection.query('SELECT * FROM Person', (err, rows, fields) => {
        if (!err){
          res.render('person',{rows:rows,type:1});
        }
        else
            console.log(err);
    })
});

app.get('/persontype', (req, res) => {
    mysqlConnection.query('SELECT * FROM PersonType', (err, rows, fields) => {
        if (!err)
            res.render('person',{rows:rows,type:2});
        else
            console.log(err);
    })
});

app.get('/staff', (req, res) => {
    mysqlConnection.query('SELECT * FROM Staff', (err, rows, fields) => {
        if (!err)
        res.render('person',{rows:rows,type:3});
        else
            console.log(err);
    })
});


app.get('/faculty', (req, res) => {
    mysqlConnection.query('SELECT * FROM Faculty', (err, rows, fields) => {
        if (!err)
        res.render('person',{rows:rows,type:4});
        else
            console.log(err);
    })
});

app.get('/student', (req, res) => {
    mysqlConnection.query('SELECT * FROM Student', (err, rows, fields) => {
        if (!err)
        res.render('person',{rows:rows,type:5});
        else
            console.log(err);
    })
});

app.get('/vehicle', (req, res) => {
    mysqlConnection.query('SELECT * FROM Vehicle', (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    })
});


app.get('/meal_delivery_location', (req, res) => {
    mysqlConnection.query('SELECT * FROM Meal_delivery_location', (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    })
});


app.get('/meal_provider', (req, res) => {
    mysqlConnection.query('SELECT * FROM Meal_provider', (err, rows, fields) => {
        if (!err)
        res.render('hangout',{qs:rows});
        else
            console.log(err);
    })
});


app.get('/products', (req, res) => {
  var sql= "SELECT StudentDriver.studentDriverId, Person.name,StudentDriver.major,StudentDriver.isStudentDriver  FROM StudentDriver JOIN Person ON StudentDriver.personId = Person.personId";
    mysqlConnection.query(sql, (err, rows, fields) => {
        if (!err)
        res.render('students',{qs:rows});
        else
            console.log(err);
    })
});


app.get('/studentsyes', (req, res) => {
  var sql= "SELECT StudentDriver.studentDriverId, StudentDriver.name,StudentDriver.major,StudentDriver.isStudentDriver  FROM StudentDriver ";
    mysqlConnection.query(sql, (err, rows, fields) => {
        if (!err)
        res.render('students',{qs:rows});
        else
            console.log(err);
    })
});

app.get('/meal_order', (req, res) => {
    mysqlConnection.query('SELECT * FROM Meal_order', (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    })
});


app.get('/students/:id', (req, res) => {
    mysqlConnection.query('DELETE FROM StudentDriver WHERE studentDriverId = ?', [req.params.id], (err, rows, fields) => {
        if (!err){
        var sql= "SELECT StudentDriver.studentDriverId, StudentDriver.name,StudentDriver.major,StudentDriver.isStudentDriver  FROM StudentDriver ";
          mysqlConnection.query(sql, (err, rows, fields) => {
              if (!err)
              res.render('students',{qs:rows});
              else
                  console.log(err);
          })
        }
        else
            console.log(err);
    })
});


//Update an employees
app.get('/updatestudent/:id',urlencodedParser, function(req, res) {
  var id=req.params.id
  res.render('update',{id:id});

    // let emp = req.body;
    // var sql = "SET @EmpID = ?;SET @Name = ?;SET @EmpCode = ?;SET @Salary = ?; \
    // CALL EmployeeAddOrEdit(@EmpID,@Name,@EmpCode,@Salary);";
    // mysqlConnection.query(sql, [emp.EmpID, emp.Name, emp.EmpCode, emp.Salary], (err, rows, fields) => {
    //     if (!err)
    //         res.send('Updated successfully');
    //     else
    //         console.log(err);
    // })
});



app.post('/sqlupdate',urlencodedParser, function(req, res) {
  console.log(req.body);
  // res.render('update',{id:id});

    let stu = req.body;
    var sql = "UPDATE studentdriver SET name=?,major=?,isStudentDriver=? WHERE studentDriverId = ?";
    mysqlConnection.query(sql, [stu.name,stu.major, stu.isStudentDriver,stu.studentDriverId], (err, rows, fields) => {
        if (!err)
        {
        var sql= "SELECT StudentDriver.studentDriverId, StudentDriver.name,StudentDriver.major,StudentDriver.isStudentDriver  FROM StudentDriver ";
          mysqlConnection.query(sql, (err, rows, fields) => {
              if (!err)
              res.render('students',{qs:rows});
              else
                  console.log(err);
          })
        }
        else
            console.log(err);
    })
});

app.get('/newstudent',urlencodedParser, function(req, res) {
  var id=req.params.id
  res.render('insert');
});

app.post('/sqlinsert',urlencodedParser, function(req, res) {
var k=parseInt(req.body.studentDriverId);
  // res.render('update',{id:id});
  console.log(k);
console.log(typeof(k));
    let stu = req.body;
    var sql = "INSERT INTO studentdriver (personId,gradyear,name, major,isStudentDriver) VALUES (?,?,?,?,?)";
    mysqlConnection.query(sql, [null,null,stu.name,stu.major, stu.isStudentDriver], (err, rows, fields) => {
        if (!err)
        {
        var sql= "SELECT StudentDriver.studentDriverId, StudentDriver.name,StudentDriver.major,StudentDriver.isStudentDriver  FROM StudentDriver ";
          mysqlConnection.query(sql, (err, rows, fields) => {
              if (!err)
              res.render('students',{qs:rows});
              else
                  console.log(err);
          })
        }
        else
            console.log(err);
    })
});
